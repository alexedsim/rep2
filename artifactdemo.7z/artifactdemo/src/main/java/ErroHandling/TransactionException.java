package ErroHandling;

public class TransactionException extends RuntimeException{

    TransactionException(TransactionResponseError transactionResponseError){
        super(transactionResponseError.toString());
    }
}
