package com.example.artifactdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
